# S01 lab notebook

Measurements, notes and explanations from Pico Bench Quest.

## Mission 1: Light the airlock lamp (2026-11-05)

## Mission 2: Control the lamp from code (2026-11-06)

## Mission 3: The heartbeat (2026-11-06)

## Mission 4: The door button (2026-11-07)

## Mission 5: The interlock (2026-11-09)

## Mission 6: The toggle latch (2026-11-09)

## Mission 7: Boss: the airlock sequence (2026-11-09)

## PCB Mission 1: Schematic: symbols and wires (2026-11-16)

## PCB Mission 2: Simulate the LED current
- Note: I use KiCad's built-in ngspice simulator to test the real schematic before ordering boards. I attach suitable models, check pin mapping, exclude non-electrical parts, and use the simulation ground symbol so node 0 exists. Then I run an operating point or transient analysis, remembering the results are only as good as the models.
- In my words: ngspice is an open-source SPICE circuit simulator, and it comes built into KiCad’s schematic editor (Inspect → Simulator). You draw a schematic, give parts simulation models, pick an analysis, and plot the results. The common analyses are operating point, DC sweep, AC frequency response, and transient (signals over time). You don’t need a separate tool or have to export a netlist by hand. KiCad builds the netlist from the same schematic you’ll use for the PCB.

Why it matters

You can check a design before spending money on boards. For example, you can confirm a filter’s cutoff frequency, find out whether an op-amp stage clips, check a regulator’s startup, or see how a transistor’s bias point moves with temperature. Because the simulation uses your real schematic, the design and the analysis stay in sync. Simulating separately in another tool tends to drift from the schematic over time. Catching a wrong resistor value in simulation costs a few minutes. Catching it on a fabricated board costs a respin.

One mistake to avoid

Don’t assume every symbol can be simulated. Many library parts, especially ICs and connectors, have no SPICE model attached. Others use a pin order that doesn’t match the model’s node order. The simulation may then fail, or it may run and give quietly wrong results. Use the Simulation Model editor to attach vendor models and check the pin mapping. Mark parts that shouldn’t be simulated, like mounting holes, with “Exclude from simulation.” Also make sure the circuit has a ground node named “0” or GND.
